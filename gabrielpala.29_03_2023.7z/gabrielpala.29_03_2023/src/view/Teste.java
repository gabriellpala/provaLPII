package view;

import java.util.Scanner;

import model.Animal;
import model.Cliente;
import model.Funcionario;
import model.Servico;
import model.realizarVenda;

public class Teste {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o nome do funcionário: ");
        String nomeFuncionario = scanner.nextLine();

        System.out.println("Digite o cargo do funcionário: ");
        String cargoFuncionario = scanner.nextLine();

        Funcionario funcionario = new Funcionario(nomeFuncionario, cargoFuncionario);

        System.out.println("Digite o nome do animal: ");
        String nomeAnimal = scanner.nextLine();

        System.out.println("Digite a idade do animal: ");
        int idadeAnimal = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha deixada pelo nextInt()

        System.out.println("Digite a espécie do animal: ");
        String especieAnimal = scanner.nextLine();

        Animal animal = new Animal(nomeAnimal, idadeAnimal, especieAnimal);

        System.out.println("Digite o nome do cliente: ");
        String nomeCliente = scanner.nextLine();

        System.out.println("Digite o endereço do cliente: ");
        String enderecoCliente = scanner.nextLine();

        System.out.println("Digite o telefone do cliente: ");
        String telefoneCliente = scanner.nextLine();

        Cliente cliente = new Cliente(nomeCliente, enderecoCliente, telefoneCliente);

        System.out.println("Digite a descrição do serviço: ");
        String descricaoServico = scanner.nextLine();

        System.out.println("Digite o preço do serviço: ");
        double precoServico = scanner.nextDouble();

        Servico servico = new Servico(descricaoServico, precoServico, cliente, animal);

        funcionario.realizarVenda(new realizarVenda("Produto 1", 10.0)); // Exemplo de venda de produto

        System.out.println("Serviço cadastrado: " + servico.getId());
        System.out.println("Produtos vendidos: " + funcionario.getListaProduto());
    }
}
