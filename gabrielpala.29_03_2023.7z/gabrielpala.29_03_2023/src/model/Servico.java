package model;

public class Servico {
    private int id;
    private String descricao;
    private double preco;
    private Cliente cliente;
    private Animal animal;

    private static int proximoId = 1;

    public Servico(String descricao, double preco, Cliente cliente, Animal animal) {
        this.id = proximoId++;
        this.descricao = descricao;
        this.preco = preco;
        this.cliente = cliente;
        this.animal = animal;
    }

    public int getId() {
        return id;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getPreco() {
        return preco;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Animal getAnimal() {
        return animal;
    }
}
