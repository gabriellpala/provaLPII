package model;

import java.util.ArrayList;
import java.util.List;

public class Funcionario {
    private String nome;
    private String cargo;
    private Animal animal;
    private Cliente cliente;
    private List<Servico> listaServico;
    private List<realizarVenda> listaProduto;

    public Funcionario(String nome, String cargo) {
        this.nome = nome;
        this.cargo = cargo;
        listaServico = new ArrayList<>();
        listaProduto = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public String getCargo() {
        return cargo;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<Servico> getListaServico() {
        return listaServico;
    }

    public List<realizarVenda> getListaProduto() {
        return listaProduto;
    }

    public void realizarVenda(realizarVenda produto) {
        listaProduto.add(produto);


    }
}
